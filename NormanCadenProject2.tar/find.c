#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include "sys/stat.h"
#include "sys/types.h"
#include "dirent.h"
#include "string.h"
#include <unistd.h>
#include <time.h>

typedef enum {false, true} bool;

char* buildCommandString(char *command, char params[], int sizeOfParams, int iter)
{
    //takes a param buffer and constructs a string of its contents to executed as a command
    //have to do this because most commands have an arbitrary number of arguments to be passed
    if(iter == sizeOfParams)
    {
        return command;
    }
    else
    {
        strcat(command,&params[iter]);
        char *newCommandString = buildCommandString(command,params,sizeOfParams,iter++);
        return newCommandString;
    }
}
int executeCommand(char *path, char *command, char params[])
{
    char *noCom = "noCom";
    char *space = " ";
    char *delLong = "-delete";
    char *delShort = "-d";



    if (strcmp(command,noCom) == 0)
    {
        //then we dont need to execute any command
        return 0;
    }

    if(strcmp(command,delLong) == 0 || strcmp(command,delShort) == 0)
    {
        //delete is an odd man out and requires its on syscall
        if (remove(path) == 0)
        {
            printf("Deleted file %s\n",path);
            fflush(stdout);
            return 0;
        }
        else
        {
            return -1;
        }
    }
    else
    {
        //all other bash commands are called by system()
        char *commandStrTemp = malloc(sizeof(char) *2000);
        commandStrTemp = strcat(command,space);
        //calculate size of param buffer
        int sizeOfParam = sizeof(params)/sizeof(char);
        int iter = 0;
        //build our command string
        char *finalCommandString = buildCommandString(commandStrTemp, params, sizeOfParam, iter);
        //execute that command string
        return system(finalCommandString);
    }
}

void findMMin(char *cwd,int mMin,bool lessThan, char *command, char params[])
{
    //finds files accessed either earlier or later than the min value
    //passed. Min is in minutes and if lessThan = true than we are looking for
    //all files accessed within the time frame. If lessThan = false than we are looking
    //for all files accessed after the time given
    DIR *subDirPtr = opendir(cwd);
    struct dirent *subDirent;
    struct stat *fileStatBuf = malloc(sizeof(struct stat));

    char dot[] = ".";
    char dubDot[] = "..";
    char slash[] = "/";
    char *retFilePath = "\0";


    if (subDirPtr != NULL)
    {
        //iterate through the contents of the directory
        while((subDirent = readdir(subDirPtr)) != NULL)
        {
            char *temp = subDirent->d_name;
            //construct a new file path string with current file name
            char *tempFullPath = malloc(sizeof(char) *2000);
            tempFullPath = strcpy(tempFullPath, cwd);
            strcat(tempFullPath,slash);
            strcat(tempFullPath, temp);

            //open up file stat to see if the criteria is met
            if (stat(tempFullPath,fileStatBuf) == 0)
            {
                // get current time
                time_t t = time(NULL);
                int currentTime = t;
                // get last accessed time for this file
                int minLastAccessed = currentTime - fileStatBuf->st_mtime;
                // convert the minutes specified into seconds
                int minInSeconds = mMin *60;

                //check if we are looking for less than the criteria
                //of greater than and then compare last accessed
                if (lessThan == true && minLastAccessed < minInSeconds)
                {
                    //we got a hit!
                    printf("%s\n",tempFullPath);
                    //execute any commands that were passed
                    if (executeCommand(tempFullPath,command,params) != 0)
                    {
                        fprintf(stderr,"could not execute command %s on file %s",command,tempFullPath);
                    }
                }
                if (lessThan == false && minLastAccessed > minInSeconds)
                {
                    //we got a hit!
                    printf("%s\n",tempFullPath);
                    if (executeCommand(tempFullPath,command,params) != 0)
                    {
                        fprintf(stderr,"could not execute command %s on file %s",command,tempFullPath);
                    }
                }
            }

            if(strcmp(temp,dot) != 0 && strcmp(temp,dubDot) != 0)
            {
                //see if we can open this file as a subdirectory
                DIR *tempSubDirPtr = opendir(tempFullPath);

                if (tempSubDirPtr != NULL)
                {
                    //we successfully opened it so we close and recursively call
                    // on the subdirectory to see if any of its contents fit criteria
                    closedir(tempSubDirPtr);
                    findMMin(tempFullPath, mMin, lessThan, command, params);
                }
            }
            free(tempFullPath);
        }
        free(fileStatBuf);
    }
    else
    {
        printf("Error: Cannot open directory\n");
        exit(2);
    }

}

void findINum(char *cwd, int iNum, char * command, char params[])
{
    DIR *subDirPtr = opendir(cwd);
    struct dirent *subDirent;
    struct stat *fileStatBuf = malloc(sizeof(struct stat));

    char dot[] = ".";
    char dubDot[] = "..";
    char slash[] = "/";

    if (subDirPtr != NULL)
    {
        // iterate through the contents of the directory
        while((subDirent = readdir(subDirPtr)) != NULL)
        {
             char *temp = subDirent->d_name;

             //avoid recursive call on a '.' or '..' file
             if(strcmp(temp,dot) != 0 && strcmp(temp,dubDot) != 0)
	         {
                //build new file string with current file name
                char * tempFullPath = malloc(sizeof(char) *2000);
                tempFullPath = strcpy(tempFullPath, cwd);
                strcat(tempFullPath,slash);
                strcat(tempFullPath, temp);


                //try to open new path
                DIR *newSubDirPtr = opendir(tempFullPath);

                if (newSubDirPtr != NULL)
                {
                    //we opened a new directory so recursively
                    //we call this on the new subdirectory to
                    //iterate through its contents
                    closedir(newSubDirPtr);
                    findINum(tempFullPath,iNum,command,params);
                }
                else
                {

                    //we know that it is not a sub dir and just a file
                    //now we check its d_name from our dirent struct
                    if (stat(tempFullPath,fileStatBuf) == 0)
                    {
                        int tempINum = fileStatBuf->st_ino;
                        if(iNum == tempINum)
                        {
                            //got a matching inum so we print and try to execute any commands
                            printf("%s \n",tempFullPath);
                            if (executeCommand(tempFullPath,command,params) != 0)
                            {
                                fprintf(stderr,"Could not execute command: %s",tempFullPath);
                            }
                        }
                    }
               }
               free(tempFullPath);
            }
        }
        free(fileStatBuf);
    }
    else
    {
        printf("Error: Cannot open directory\n");
        exit(2);
    }
}


void findName(char *cwd, char *name, char * command, char params[])

{
    DIR *subDirPtr = opendir(cwd);
    struct dirent *subDirent;

    char dot[] = ".";
    char dubDot[] = "..";
    char slash[] = "/";

    if (subDirPtr != NULL)
    {
        //iterate through the directory contents
        while((subDirent = readdir(subDirPtr)) != NULL)
        {
             char *temp = subDirent->d_name;
             //avoid any '.' or '..' directories
             if(strcmp(temp,dot) != 0 && strcmp(temp,dubDot) != 0)
	         {
	             // construct new file path string with current file name
                char * tempFullPath = malloc(sizeof(char) *2000);
                tempFullPath = strcpy(tempFullPath, cwd);
                strcat(tempFullPath,slash);
                strcat(tempFullPath, temp);


                //try to open new path
                DIR *newSubDirPtr = opendir(tempFullPath);

                if (newSubDirPtr != NULL)
                {
                    closedir(newSubDirPtr);
                    findName(tempFullPath,name,command,params);
                }
                else
                {
                    //we know that it is not a sub dir and just a file
                    //now we check its d_name from our dirent struct
                    if (strcmp(temp,name) == 0)
                    {
                        //found a matching name so we print and try
                        //to execute any commands that might have been passed
                        printf("%s \n",tempFullPath);
    
    


   
                        if (executeCommand(tempFullPath,command,params) != 0)
                        {
                            fprintf(stderr,"Could not execute command %s on file %s",command,tempFullPath);
                        }
                    }
                }
                free(tempFullPath);
            }
        }
        return;
    }
    else
    {
        printf("Error: Cannot open directory\n");
        exit(2);
    }
}

char *findDir(char *cwd,char *dirName, bool print)
{
    //this method finds the directory that was specified
    //as whereToLook at the command line
    //if we need to print the contents of that entire
    //directory than it does so and doesn't otherwise
    DIR *subDirPtr = opendir(cwd);
    struct dirent *subDirent;

    char dot[] = ".";
    char dubDot[] = "..";
    char slash[] = "/";
    char *retFilePath = "\0";


    if (subDirPtr != NULL)
    {
        while((subDirent = readdir(subDirPtr)) != NULL)
        {
            char *temp = subDirent->d_name;
            if (strcmp(temp,dirName) == 0)
            {

                char * tempFullPath = malloc(sizeof(char) *2000);
                tempFullPath = strcpy(tempFullPath, cwd);
                strcat(tempFullPath,slash);
                strcat(tempFullPath, temp);

                if (print == true)
                {
                    printDir(tempFullPath);
                }
                closedir(subDirPtr);
                retFilePath = tempFullPath;
                return retFilePath;
            }

            if(strcmp(temp,dot) != 0 && strcmp(temp,dubDot) != 0)
            {

                char *tempFullPath = malloc(sizeof(char) *2000);
                tempFullPath = strcpy(tempFullPath, cwd);
                strcat(tempFullPath,slash);
                strcat(tempFullPath, temp);
                DIR *tempSubDirPtr = opendir(tempFullPath);

                if (tempSubDirPtr != NULL)
                {
                    closedir(tempSubDirPtr);
                    retFilePath = findDir(tempFullPath,dirName,print);
                    closedir(subDirPtr);
                    return retFilePath;
                }
            }

        }
        if (retFilePath == "/0")
        {
            fprintf(stderr,"could not file directory in your current working directory\n");
            exit(2);
        }
        return retFilePath;
    }
    else
    {
        printf("Error: Cannot open directory\n");
        exit(2);
    }
}
void printDir(char *cwd)
{
    //this method prints all the contents of a given directory
    DIR *dirPtr = opendir(cwd);
    struct dirent *dirEnt;

    char *slash = "/";
    char *dot = ".";
    char *dotdot = "..";

    if (dirPtr != NULL)
    {
        while((dirEnt = readdir(dirPtr)) != NULL)
        {
            char *temp = dirEnt->d_name;
            if (strcmp(temp,dot) != 0 && strcmp(temp,dotdot) != 0)
            {

               char *tempFullPath = malloc(sizeof(char) *2000);
               tempFullPath = strcpy(tempFullPath, cwd);
               strcat(tempFullPath, slash);
               strcat(tempFullPath, temp);
               DIR *tempSubDirPtr = opendir(tempFullPath);


               if (tempSubDirPtr != NULL)
               {

                    closedir(tempSubDirPtr);
 		    printDir(tempFullPath);
	       }
               printf("%s\n",tempFullPath);
            }
        }
    }
    else
    {
        fprintf(stderr,"Could not open specified working directory\n");
    }
}

int main(int argc, char *argv[])
{
    char *params[100];

    char *cwd[PATH_MAX-10];
    // get the current working directory
    if (getcwd(cwd,sizeof(cwd)) == NULL)
    {
        fprintf(stderr,"Could not open your current working directory\n");
        return -1;
        exit(2);

    }

    if (argc == 1)
    {
        // this is the default for find
        //just print the contents of the current working directory
       printDir(cwd);
       return 0;
    }
    else
    {
        //out of default mode so now we need to parse command line arguments
        char *whereToLook = argv[1];

        if (argc == 2)
        {
            //if we have just two arguments than we need to
            //just print the directory specified in whereToLook
            //so we call findDir with printing = true
            bool printing = true;
            findDir(cwd, whereToLook, printing);
            return 0;
        }
        else if (argc == 3)
        {
            //cant have 3 arguments
            fprintf(stderr,"Missing or invalid input parameter \n");
            return -1;
        }
        else if (argc == 4)
        {
            //if we have 4 arguments we know there is
            //some search criteria so we parse the args
            char *critNameFull = "-name";
            char *critMminFull = "-mmin";
            char *critInumFull = "-inum";
            char *critNamePart = "-n";
            char *critMminPart = "-m";
            char *critInumPart = "-i";

            // we also know we are not going to execute any commands
            // so we pass noCom command and dont create a params array
            char *command = "noCom";
            char params[1];
            //we arent going to be printing out the entire contents of the
            //directory so printing is set to false
            bool printing = false;

            char *criterArg = argv[2];

            //find the directory
            char *thisDir = findDir(cwd,whereToLook,printing);


            // compare arguments and do what we are told to do
            if (strcmp(criterArg,critInumFull) == 0 || strcmp(criterArg, critInumPart) == 0)
            {
                char *iNumTemp = argv[3];
                int iNum = atoi(iNumTemp);
                findINum(thisDir,iNum,command,params);
                return 0;
            }
            else if (strcmp(criterArg,critNameFull) == 0 || strcmp(criterArg, critNamePart) == 0)
            {
                char *nameArg = argv[3];
                findName(thisDir,nameArg,command,params);
            }
            else if (strcmp(criterArg,critMminFull) == 0 || strcmp(criterArg,critMminPart) == 0)
            {
                char *mMinTemp = argv[3];
                int mMin = atoi(mMinTemp);
                if (mMin < 0)
                {
                    bool lessThan = true;
                    //convert from negative to positive after noting that it was negative
                    int posMin = mMin * -1;
                    mMin = mMin + (2 * posMin);
                    findMMin(cwd,mMin,lessThan,command, params);
                    return 0;
                }
                else if (mMin > 0)
                {
                    bool lessThan = false;
                    findMMin(cwd,mMin,lessThan,command,params);
                    return 0;
                }
                else
                {
                    fprintf(stderr,"mmin value cannot be zero\n");
                    return -1;

                }
            }
            else
            {
                fprintf(stderr,"search criteria %s not recognized",criterArg);
            }
        }
        else if (argc >= 5)
        {
            //same as above but now we have a command to execute
            // and we have to build a params buffer
            char *critNameFull = "-name";
            char *critMminFull = "-mmin";
            char *critInumFull = "-inum";
            char *critNamePart = "-n";
            char *critMminPart = "-m";
            char *critInumPart = "-i";
            char *command = argv[4];
            // have to build the params buffer
            char params[100];
            int iter = 5;
            int pIndex = 0;
            char *space = " ";

            for (iter; iter < argc; iter++)
            {
                char *strTemp = argv[iter];
                int iter2 = 0;
                for (iter2;iter2 < strlen(strTemp);iter2++)
                {
                    params[pIndex] = strTemp[iter2];
                    pIndex++;
                }
                params[pIndex] = space;
                pIndex++;
            }
            // params should now be full


            bool printing = false;

            char *criterArg = argv[2];

            char *thisDir = findDir(cwd,whereToLook,printing);

            if (strcmp(criterArg,critInumFull) == 0 || strcmp(criterArg, critInumPart) == 0)
            {
                char *iNumTemp = argv[3];
                int iNum = atoi(iNumTemp);
                findINum(thisDir,iNum,command,params);
                return 0;
            }
            else if (strcmp(criterArg,critNameFull) == 0 || strcmp(criterArg, critNamePart) == 0)
            {
                char *nameArg = argv[3];
                findName(thisDir,nameArg,command,params);
            }
            else if (strcmp(criterArg,critMminFull) == 0 || strcmp(criterArg,critMminPart) == 0)
            {
                char *mMinTemp = argv[3];
                int mMin = atoi(mMinTemp);
                if (mMin < 0)
                {
                    bool lessThan = true;
                    //convert from negative to positive after noting that it was negative
                    int posMin = mMin * -1;
                    mMin = mMin + (2 * posMin);
                    findMMin(cwd,mMin,lessThan,command, params);
                    return 0;
                }
                else if (mMin > 0)
                {
                    bool lessThan = false;
                    findMMin(cwd,mMin,lessThan,command,params);
                    return 0;
                }
                else
                {
                    fprintf(stderr,"mmin value cannot be zero\n");
                    return -1;

                }
            }
            else
            {
                fprintf(stderr,"search criteria %s not recognized",criterArg);
            }
        }
    }


    return 0;
}

